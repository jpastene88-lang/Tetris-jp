# NEON TETRIS

Juego de bloques estilo Tetris con estética cyberpunk verde (Matrix). Android nativo, Kotlin, dibujo con Canvas propio. Sin conexión, sin permisos, sin anuncios ni compras.

- `applicationId`: `cl.neontetris.game` · versión `1.0` (versionCode 1)
- `minSdk` 26 (Android 8.0) · `targetSdk` / `compileSdk` 36 (Android 16)
- Sin código nativo: el mismo APK corre en `arm64-v8a` (Galaxy S24, SM-S921B)

## Controles

| Acción | Cómo |
|---|---|
| Mover | Botones ◀ ▶ (mantener para repetir) o deslizar horizontalmente sobre el tablero |
| Rotar | Botón ROTAR o tocar el tablero |
| Caída rápida | Mantener el botón CAER |
| Caída instantánea | Toque corto en CAER o deslizar hacia abajo sobre el tablero |
| Pausa / sonido | Botones de la esquina superior derecha |

El récord y la partida en curso se guardan en el teléfono. Al salir de la app el juego queda en pausa y se recupera donde lo dejaste.

## Compilar el APK

### Opción A — en la nube con GitHub (sin instalar nada)

1. Crea un repositorio en GitHub y sube el contenido de esta carpeta (o `git push`).
2. Pestaña **Actions → Build NEON TETRIS APK → Run workflow**.
3. Al terminar (unos 5–8 min), descarga el artefacto **NEON-TETRIS-apk** → `NEON-TETRIS.apk`.

El flujo ejecuta las pruebas, compila el release firmado y valida firma, paquete y SDK (`apksigner`, `aapt2`).

### Opción B — en tu computador

Requisitos: Android Studio (o JDK 17 + Android SDK con plataforma 36).

```bash
./gradlew :app:testDebugUnitTest      # pruebas
./gradlew :app:assembleRelease        # APK firmado
```

Resultado: `app/build/outputs/apk/release/app-release.apk` (renómbralo a `NEON-TETRIS.apk` si quieres).
También puedes abrir la carpeta en Android Studio y usar **Build → Build APK(s)**.

## Instalar en el Galaxy S24

1. Pasa `NEON-TETRIS.apk` al teléfono (Google Drive, cable USB, correo, etc.) y ábrelo desde **Mis archivos**.
2. Si Android lo pide: **Configuración → Aplicaciones → (la app desde la que lo abres) → Instalar apps desconocidas → Permitir**.
3. Pulsa **Instalar**. Si Play Protect avisa de “app no reconocida”, elige **Instalar de todos modos** (el APK está firmado con una clave de pruebas, no publicada en Google Play).

## Clave de firma

`keystore/neon-tetris-test.jks` es una clave **de pruebas, pública en este proyecto** (alias `neontetris`, contraseña `neontetris`). Sirve para instalar en tu teléfono. Si algún día publicas en una tienda, genera tu propia clave y no la subas al repositorio.

## Estructura

```
app/src/main/java/cl/neontetris/game/
  engine/PieceType.kt     las 7 piezas y sus rotaciones
  engine/GameEngine.kt    reglas, puntuación, niveles, guardado (sin dependencias de Android)
  GameView.kt             interfaz Canvas, táctil, animación
  SoundManager.kt         efectos retro generados por código
  Storage.kt              récord, sonido, partida guardada
  MainActivity.kt         ciclo de vida, bordes del sistema, botón atrás
app/src/test/.../GameEngineTest.kt   15 pruebas del motor
```
