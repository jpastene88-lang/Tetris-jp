import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "cl.neontetris.game"
    compileSdk = 36

    defaultConfig {
        applicationId = "cl.neontetris.game"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
        // Sin código nativo: el APK corre igual en arm64-v8a (Galaxy S24).
    }

    // Clave de PRUEBAS incluida en el repositorio (ver README). Para publicar
    // en una tienda, reemplázala por una clave propia y privada.
    signingConfigs {
        create("release") {
            storeFile = rootProject.file("keystore/neon-tetris-test.jks")
            storePassword = "neontetris"
            keyAlias = "neontetris"
            keyPassword = "neontetris"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.1")

    testImplementation("junit:junit:4.13.2")
}
