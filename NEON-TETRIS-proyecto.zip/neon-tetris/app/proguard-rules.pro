# NEON TETRIS no usa reflexión ni librerías que requieran reglas especiales.
# Las reglas por defecto de Android (proguard-android-optimize.txt) son suficientes.
