package cl.neontetris.game.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GameEngineTest {

    private fun newGame(): GameEngine {
        val e = GameEngine(java.util.Random(42))
        e.start()
        return e
    }

    private fun filledCells(e: GameEngine): Int {
        var n = 0
        for (row in e.grid) for (v in row) if (v != 0) n++
        return n
    }

    @Test
    fun sevenPiecesWithFourCellsInEveryRotation() {
        assertEquals(7, PieceType.values().size)
        for (t in PieceType.values()) {
            assertEquals(4, t.offsets.size)
            for (rot in t.offsets) assertEquals(8, rot.size)
        }
    }

    @Test
    fun newGameIsRunningWithEmptyBoard() {
        val e = newGame()
        assertEquals(GameEngine.State.RUNNING, e.state)
        assertEquals(0, filledCells(e))
        assertEquals(0, e.score)
        assertEquals(1, e.level)
        assertTrue(e.pieceActive)
    }

    @Test
    fun boardIsTenByTwentyVisible() {
        assertEquals(10, GameEngine.COLS)
        assertEquals(20, GameEngine.VISIBLE_ROWS)
    }

    @Test
    fun pieceStopsAtWalls() {
        val e = newGame()
        var guard = 0
        while (e.moveLeft() && guard++ < 20) { }
        assertFalse(e.moveLeft())
        guard = 0
        while (e.moveRight() && guard++ < 20) { }
        assertFalse(e.moveRight())
    }

    @Test
    fun rotationChangesOrientationInOpenSpace() {
        val e = newGame()
        e.debugSetPiece(PieceType.T, 0, 3, 8)
        assertTrue(e.rotate())
        assertEquals(1, e.curRot)
        e.rotate(); e.rotate(); e.rotate()
        assertEquals(0, e.curRot)
    }

    @Test
    fun hardDropLocksPieceAtBottomAndScores() {
        val e = newGame()
        val dist = e.hardDrop()
        assertTrue(dist > 0)
        assertEquals(4, filledCells(e))
        assertEquals(2 * dist, e.score)
        // Debe haber aparecido la siguiente pieza.
        assertEquals(GameEngine.State.RUNNING, e.state)
        assertTrue(e.pieceActive)
    }

    @Test
    fun completeLineIsClearedAndScored() {
        val e = newGame()
        val bottom = GameEngine.ROWS - 1
        for (c in 0 until 3) e.grid[bottom][c] = 1
        for (c in 7 until 10) e.grid[bottom][c] = 1
        e.debugSetPiece(PieceType.I, 0, 3, 1)
        val dist = e.hardDrop()
        assertEquals(1, e.clearingRows.size)
        e.update(GameEngine.CLEAR_ANIM_MS + 1)
        assertEquals(1, e.lines)
        assertEquals(100 + 2 * dist, e.score)
        assertTrue(e.grid[bottom].all { it == 0 })
    }

    @Test
    fun levelRisesAndFallGetsFaster() {
        var prev = GameEngine.intervalForLevel(1)
        for (lvl in 2..15) {
            val cur = GameEngine.intervalForLevel(lvl)
            assertTrue(cur <= prev)
            prev = cur
        }
        assertTrue(GameEngine.intervalForLevel(1) > GameEngine.intervalForLevel(10))
    }

    @Test
    fun gravityMovesPieceDownAutomatically() {
        val e = newGame()
        val y0 = e.curY
        e.update(GameEngine.intervalForLevel(1) + 1)
        assertEquals(y0 + 1, e.curY)
    }

    @Test
    fun softDropIsFasterThanGravity() {
        val a = newGame()
        val b = newGame()
        b.softDrop = true
        a.update(300.0)
        b.update(300.0)
        assertTrue(b.curY > a.curY)
    }

    @Test
    fun stackingToTheTopEndsTheGame() {
        val e = newGame()
        var n = 0
        while (e.state == GameEngine.State.RUNNING && n++ < 80) {
            e.hardDrop()
            e.update(GameEngine.CLEAR_ANIM_MS + 1)
        }
        assertEquals(GameEngine.State.GAME_OVER, e.state)
    }

    @Test
    fun pauseFreezesTheGameAndResumeContinues() {
        val e = newGame()
        e.pause()
        assertEquals(GameEngine.State.PAUSED, e.state)
        val y = e.curY
        e.update(5000.0)
        assertEquals(y, e.curY)
        assertFalse(e.moveLeft())
        e.resume()
        assertEquals(GameEngine.State.RUNNING, e.state)
    }

    @Test
    fun sevenBagGivesEachPieceTwiceInFourteenDraws() {
        val e = GameEngine(java.util.Random(7))
        val counts = IntArray(7)
        for (i in 0 until 14) counts[e.debugDraw().ordinal]++
        for (c in counts) assertEquals(2, c)
    }

    @Test
    fun saveAndRestoreKeepsTheGame() {
        val a = newGame()
        a.moveLeft()
        a.hardDrop()
        a.update(100.0)
        val data = a.serialize()

        val b = GameEngine()
        assertTrue(b.restore(data))
        assertEquals(GameEngine.State.PAUSED, b.state)
        assertEquals(a.score, b.score)
        assertEquals(a.curType, b.curType)
        assertEquals(a.nextType, b.nextType)
        for (r in 0 until GameEngine.ROWS) {
            assertEquals(a.grid[r].toList(), b.grid[r].toList())
        }
    }

    @Test
    fun restoreRejectsGarbage() {
        val e = GameEngine()
        assertFalse(e.restore(""))
        assertFalse(e.restore("1;x;y"))
        assertFalse(e.restore("2;0;0;1;0;0;3;1;1;1;1;;" + "0".repeat(220)))
        assertEquals(GameEngine.State.READY, e.state)
    }
}
