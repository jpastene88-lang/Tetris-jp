package cl.neontetris.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.util.SparseArray
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import cl.neontetris.game.engine.GameEngine
import cl.neontetris.game.engine.PieceType
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Toda la interfaz del juego se dibuja con Canvas: pantalla de inicio, tablero,
 * HUD, botones táctiles y las capas de pausa / fin de partida.
 */
class GameView(
    context: Context,
    private val engine: GameEngine,
    private val storage: Storage,
    private val sound: SoundManager
) : View(context) {

    private enum class Btn {
        LEFT, RIGHT, ROTATE, DOWN, PAUSE, SOUND,
        PLAY, RESUME, RESTART, HOME, SOUND_MENU
    }

    private class Gesture(val startX: Float, val startY: Float, val startTime: Long) {
        var lastX = startX
        var moved = false
        var hard = false
    }

    private class Drop(var x: Float, var y: Float, var speed: Float, var seed: Int)

    // ------------------------------------------------------------- estado UI

    /** true = pantalla de inicio. */
    var showHome = true

    private var hostResumed = false
    private var newRecord = false

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    // ------------------------------------------------------------- pinceles

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        letterSpacing = 0.06f
    }
    private val rainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textAlign = Paint.Align.CENTER
    }
    private val path = Path()
    private val tmpRect = RectF()

    private val neon = Color.rgb(57, 255, 20)
    private val neonDim = Color.rgb(0, 150, 50)
    private val pieceColors = intArrayOf(
        0,
        Color.rgb(57, 255, 20),   // I
        Color.rgb(182, 255, 59),  // O
        Color.rgb(0, 255, 156),   // T
        Color.rgb(0, 230, 118),   // S
        Color.rgb(118, 255, 3),   // Z
        Color.rgb(0, 200, 83),    // J
        Color.rgb(100, 255, 218)  // L
    )

    // ------------------------------------------------------------- geometría

    private var insetL = 0f
    private var insetT = 0f
    private var insetR = 0f
    private var insetB = 0f

    private var cell = 0f
    private var boardLeft = 0f
    private var boardTop = 0f
    private var boardW = 0f
    private var boardH = 0f
    private var controlsTop = 0f
    private var gridLines = FloatArray(0)
    private val hudRect = RectF()
    private val nextRect = RectF()
    private val gameRects = HashMap<Btn, RectF>()
    private val overlayRects = Array(3) { RectF() }

    fun setSafeInsets(l: Int, t: Int, r: Int, b: Int) {
        insetL = l.toFloat()
        insetT = t.toFloat()
        insetR = r.toFloat()
        insetB = b.toFloat()
        layoutUi()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutUi()
        initRain()
    }

    private fun layoutUi() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val pad = dp(14f)
        val safeL = insetL + pad
        val safeR = w - insetR - pad
        val safeT = insetT + dp(8f)
        val safeB = h - insetB - dp(12f)
        val safeW = safeR - safeL
        val safeH = safeB - safeT

        val ctrlH = min(safeH * 0.26f, dp(210f))
        controlsTop = safeB - ctrlH
        val hudH = min(safeH * 0.13f, dp(92f))
        hudRect.set(safeL, safeT, safeR, safeT + hudH)

        val areaTop = hudRect.bottom + dp(10f)
        val areaBottom = controlsTop - dp(12f)
        cell = min((areaBottom - areaTop) / GameEngine.VISIBLE_ROWS, safeW / GameEngine.COLS)
        boardW = cell * GameEngine.COLS
        boardH = cell * GameEngine.VISIBLE_ROWS
        boardLeft = safeL + (safeW - boardW) / 2f
        boardTop = areaTop + ((areaBottom - areaTop) - boardH) / 2f

        val lines = ArrayList<Float>()
        for (i in 1 until GameEngine.COLS) {
            val x = boardLeft + i * cell
            lines.add(x); lines.add(boardTop); lines.add(x); lines.add(boardTop + boardH)
        }
        for (i in 1 until GameEngine.VISIBLE_ROWS) {
            val y = boardTop + i * cell
            lines.add(boardLeft); lines.add(y); lines.add(boardLeft + boardW); lines.add(y)
        }
        gridLines = lines.toFloatArray()

        // HUD derecha: vista previa + pausa + sonido
        val side = hudH
        nextRect.set(hudRect.right - side, hudRect.top, hudRect.right, hudRect.top + side)
        val small = side * 0.46f
        val gap = side - 2 * small
        val bx = nextRect.left - dp(10f) - small
        gameRects[Btn.PAUSE] = RectF(bx, hudRect.top, bx + small, hudRect.top + small)
        gameRects[Btn.SOUND] =
            RectF(bx, hudRect.top + small + gap, bx + small, hudRect.top + small + gap + small)

        // Controles inferiores
        val g = dp(12f)
        val half = (safeW - g) / 2f
        val bs = min(ctrlH, (half - g) / 2f)
        val cy = controlsTop + (ctrlH - bs) / 2f
        gameRects[Btn.LEFT] = RectF(safeL, cy, safeL + bs, cy + bs)
        gameRects[Btn.RIGHT] = RectF(safeL + bs + g, cy, safeL + 2 * bs + g, cy + bs)
        val rx = safeL + half + g
        val rotH = (ctrlH - g) * 0.58f
        gameRects[Btn.ROTATE] = RectF(rx, controlsTop, safeR, controlsTop + rotH)
        gameRects[Btn.DOWN] = RectF(rx, controlsTop + rotH + g, safeR, safeB)

        // Botones de las pantallas superpuestas
        val ow = min(safeW * 0.86f, dp(300f))
        val oh = dp(56f)
        val og = dp(16f)
        val oTop = h * 0.5f
        for (i in 0 until 3) {
            val top = oTop + i * (oh + og)
            overlayRects[i].set((w - ow) / 2f, top, (w + ow) / 2f, top + oh)
        }
    }

    // ------------------------------------------------------------ lluvia Matrix

    private val rainChars = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄ0123456789".toCharArray()
    private val drops = ArrayList<Drop>()
    private val rainRandom = java.util.Random(1234)
    private var rainTick = 0
    private var rainTickMs = 0.0
    private val trail = 9

    private fun initRain() {
        drops.clear()
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val colW = dp(26f)
        val n = (w / colW).toInt() + 1
        for (i in 0 until n) {
            drops.add(
                Drop(
                    i * colW + colW / 2f,
                    -rainRandom.nextFloat() * h,
                    dp(40f + rainRandom.nextFloat() * 80f),
                    rainRandom.nextInt(1000)
                )
            )
        }
    }

    private fun stepRain(dtMs: Double) {
        val h = height.toFloat()
        val charH = dp(15f)
        rainTickMs += dtMs
        if (rainTickMs > 140.0) {
            rainTickMs = 0.0
            rainTick++
        }
        for (d in drops) {
            d.y += d.speed * (dtMs / 1000.0).toFloat()
            if (d.y - trail * charH > h) {
                d.y = -rainRandom.nextFloat() * h * 0.4f
                d.speed = dp(40f + rainRandom.nextFloat() * 80f)
                d.seed = rainRandom.nextInt(1000)
            }
        }
    }

    private fun drawRain(c: Canvas, baseAlpha: Int) {
        val charH = dp(15f)
        rainPaint.textSize = charH
        for (d in drops) {
            for (k in 0 until trail) {
                val cy = d.y - k * charH
                if (cy < -charH || cy > height + charH) continue
                val idx = abs(d.seed * 31 + k * 17 + (if (k == 0) rainTick else 0)) % rainChars.size
                val a = (baseAlpha * (1f - k / trail.toFloat())).toInt()
                rainPaint.color = if (k == 0) Color.argb(a, 190, 255, 200) else Color.argb(a, 0, 255, 70)
                c.drawText(rainChars, idx, 1, d.x, cy, rainPaint)
            }
        }
    }

    // ------------------------------------------------------------ bucle

    private var loopPosted = false
    private var lastFrameNanos = 0L
    private var frameAcc = 0.0
    private val frameCallback = Choreographer.FrameCallback { now ->
        loopPosted = false
        onFrame(now)
    }

    private fun needsAnimation(): Boolean = showHome || engine.state == GameEngine.State.RUNNING

    fun ensureLoop() {
        if (!loopPosted && hostResumed && needsAnimation()) {
            loopPosted = true
            Choreographer.getInstance().postFrameCallback(frameCallback)
        }
    }

    private fun stopLoop() {
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        loopPosted = false
        lastFrameNanos = 0L
        frameAcc = 0.0
    }

    private fun onFrame(now: Long) {
        if (lastFrameNanos == 0L) lastFrameNanos = now
        var dt = (now - lastFrameNanos) / 1_000_000.0
        lastFrameNanos = now
        if (dt > 50.0) dt = 50.0
        frameAcc += dt

        // ~60 fps aunque la pantalla vaya a 120 Hz: menos consumo de batería.
        if (frameAcc >= 15.0) {
            step(frameAcc)
            frameAcc = 0.0
            invalidate()
        }
        syncScreenOn()
        if (needsAnimation()) {
            ensureLoop()
        } else {
            lastFrameNanos = 0L
            frameAcc = 0.0
            invalidate()
        }
    }

    private var heldDir = 0
    private var nextRepeatAt = 0L
    private var downPressedAt = 0L

    private fun step(dtMs: Double) {
        stepRain(dtMs)
        if (!showHome && engine.state == GameEngine.State.RUNNING) {
            if (heldDir != 0) {
                val now = SystemClock.uptimeMillis()
                if (now >= nextRepeatAt) {
                    if (heldDir < 0) engine.moveLeft() else engine.moveRight()
                    nextRepeatAt = now + REPEAT_MS
                }
            }
            engine.update(dtMs)
        }
    }

    private fun syncScreenOn() {
        val want = !showHome && engine.state == GameEngine.State.RUNNING
        if (keepScreenOn != want) keepScreenOn = want
    }

    // ------------------------------------------------------- ciclo de vida

    fun onHostResume() {
        hostResumed = true
        ensureLoop()
        invalidate()
    }

    fun onHostPause() {
        hostResumed = false
        releaseInput()
        engine.pause()
        saveState()
        stopLoop()
        syncScreenOn()
    }

    /** Se llama cuando MainActivity restauró una partida guardada (queda en pausa). */
    fun onRestoredGame() {
        showHome = false
    }

    fun saveState() {
        if (engine.score > storage.best) storage.best = engine.score
        storage.savedGame = when (engine.state) {
            GameEngine.State.RUNNING, GameEngine.State.PAUSED -> engine.serialize()
            else -> null
        }
    }

    /** Botón "atrás". Devuelve false si la app debe cerrarse. */
    fun handleBack(): Boolean {
        return when {
            showHome -> false
            engine.state == GameEngine.State.RUNNING -> {
                engine.pause(); ensureLoop(); invalidate(); true
            }
            else -> {
                showHome = true; ensureLoop(); invalidate(); true
            }
        }
    }

    // ------------------------------------------------------- eventos del juego

    init {
        engine.listener = object : GameEngine.Listener {
            override fun onMove() { sound.play(SoundManager.Sfx.MOVE) }
            override fun onRotate() { sound.play(SoundManager.Sfx.ROTATE) }
            override fun onHardDrop() { sound.play(SoundManager.Sfx.DROP) }
            override fun onLock() { sound.play(SoundManager.Sfx.LOCK) }
            override fun onLinesCleared(count: Int) { sound.play(SoundManager.Sfx.LINE) }
            override fun onLevelUp(level: Int) { sound.play(SoundManager.Sfx.LEVEL) }
            override fun onGameOver() {
                sound.play(SoundManager.Sfx.OVER)
                if (engine.score > storage.best) {
                    storage.best = engine.score
                    newRecord = true
                }
                storage.savedGame = null
                heldDir = 0
            }
        }
        sound.muted = storage.muted
        keepScreenOn = false
    }

    private fun startNewGame() {
        newRecord = false
        showHome = false
        heldDir = 0
        engine.start()
        ensureLoop()
        invalidate()
    }

    private fun activate(b: Btn) {
        when (b) {
            Btn.PLAY, Btn.RESTART -> startNewGame()
            Btn.RESUME -> {
                showHome = false
                engine.resume()
            }
            Btn.HOME -> showHome = true
            Btn.PAUSE -> engine.pause()
            Btn.SOUND, Btn.SOUND_MENU -> {
                storage.muted = !storage.muted
                sound.muted = storage.muted
            }
            else -> {}
        }
        ensureLoop()
        invalidate()
    }

    // ------------------------------------------------------------ táctil

    private val pointerBtn = SparseArray<Btn>()
    private val gestures = SparseArray<Gesture>()
    private val pressed = HashSet<Btn>()

    private fun overlayButtons(): List<Pair<Btn, String>> = when {
        showHome && engine.state == GameEngine.State.PAUSED -> listOf(
            Btn.RESUME to "CONTINUAR", Btn.PLAY to "NUEVA PARTIDA", Btn.SOUND_MENU to soundLabel()
        )
        showHome -> listOf(Btn.PLAY to "JUGAR", Btn.SOUND_MENU to soundLabel())
        engine.state == GameEngine.State.PAUSED -> listOf(
            Btn.RESUME to "REANUDAR", Btn.RESTART to "REINICIAR", Btn.HOME to "INICIO"
        )
        engine.state == GameEngine.State.GAME_OVER -> listOf(
            Btn.RESTART to "REINICIAR", Btn.HOME to "INICIO"
        )
        else -> emptyList()
    }

    private fun soundLabel() = if (storage.muted) "SONIDO: NO" else "SONIDO: SI"

    private fun rectOf(b: Btn): RectF? {
        val list = overlayButtons()
        for (i in list.indices) if (list[i].first == b) return overlayRects[i]
        return gameRects[b]
    }

    private fun hitButton(x: Float, y: Float): Btn? {
        val list = overlayButtons()
        if (list.isNotEmpty()) {
            for (i in list.indices) if (overlayRects[i].contains(x, y)) return list[i].first
            return null
        }
        val slop = dp(4f)
        for (b in arrayOf(Btn.LEFT, Btn.RIGHT, Btn.ROTATE, Btn.DOWN, Btn.PAUSE, Btn.SOUND)) {
            val r = gameRects[b] ?: continue
            if (x >= r.left - slop && x <= r.right + slop && y >= r.top - slop && y <= r.bottom + slop) {
                return b
            }
        }
        return null
    }

    private fun isPlaying() = !showHome && engine.state == GameEngine.State.RUNNING

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                pointerDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) pointerMove(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                pointerUp(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_CANCEL -> releaseInput()
        }
        invalidate()
        return true
    }

    private fun pointerDown(id: Int, x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        val b = hitButton(x, y)
        if (b != null) {
            pointerBtn.put(id, b)
            pressed.add(b)
            if (isPlaying()) {
                when (b) {
                    Btn.LEFT -> {
                        engine.moveLeft(); heldDir = -1; nextRepeatAt = now + DAS_MS
                    }
                    Btn.RIGHT -> {
                        engine.moveRight(); heldDir = 1; nextRepeatAt = now + DAS_MS
                    }
                    Btn.ROTATE -> engine.rotate()
                    Btn.DOWN -> {
                        engine.softDrop = true; downPressedAt = now
                    }
                    else -> {}
                }
            }
            return
        }
        if (isPlaying() && y < controlsTop) {
            gestures.put(id, Gesture(x, y, now))
        }
    }

    private fun pointerMove(id: Int, x: Float, y: Float) {
        val g = gestures.get(id) ?: return
        if (!isPlaying()) return
        val stepPx = cell * 0.9f
        val steps = ((x - g.lastX) / stepPx).toInt()
        if (steps != 0) {
            repeat(abs(steps)) { if (steps > 0) engine.moveRight() else engine.moveLeft() }
            g.lastX += steps * stepPx
            g.moved = true
        }
        val dy = y - g.startY
        if (!g.hard && dy > cell * 3.5f && dy > abs(x - g.startX) * 1.2f) {
            engine.hardDrop()
            g.hard = true
            g.moved = true
        }
    }

    private fun pointerUp(id: Int, x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        val b = pointerBtn.get(id)
        if (b != null) {
            pointerBtn.remove(id)
            pressed.remove(b)
            when (b) {
                Btn.LEFT -> if (heldDir < 0) heldDir = 0
                Btn.RIGHT -> if (heldDir > 0) heldDir = 0
                Btn.DOWN -> {
                    engine.softDrop = false
                    // Toque corto = caída instantánea; mantener = caída rápida.
                    if (isPlaying() && now - downPressedAt < HARD_TAP_MS) engine.hardDrop()
                }
                Btn.ROTATE -> {}
                else -> {
                    val r = rectOf(b)
                    if (r != null && r.contains(x, y)) activate(b)
                }
            }
        }
        val g = gestures.get(id)
        if (g != null) {
            gestures.remove(id)
            val moved = abs(x - g.startX) > dp(12f) || abs(y - g.startY) > dp(12f)
            if (isPlaying() && !g.moved && !moved && now - g.startTime < 260) engine.rotate()
        }
        ensureLoop()
    }

    private fun releaseInput() {
        pointerBtn.clear()
        gestures.clear()
        pressed.clear()
        heldDir = 0
        engine.softDrop = false
    }

    // ------------------------------------------------------------ dibujo

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.BLACK)
        if (width == 0 || cell == 0f) return

        if (showHome) {
            drawRain(c, 95)
            drawHome(c)
            return
        }
        drawRain(c, 34)
        drawHud(c)
        drawBoard(c)
        drawControls(c)
        when (engine.state) {
            GameEngine.State.PAUSED -> drawPause(c)
            GameEngine.State.GAME_OVER -> drawGameOver(c)
            else -> {}
        }
    }

    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        align: Paint.Align = Paint.Align.LEFT, glow: Boolean = false
    ) {
        textPaint.textSize = size
        textPaint.color = color
        textPaint.textAlign = align
        if (glow) textPaint.setShadowLayer(size * 0.5f, 0f, 0f, color) else textPaint.clearShadowLayer()
        c.drawText(s, x, y, textPaint)
        textPaint.clearShadowLayer()
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    private fun drawCell(c: Canvas, x: Float, y: Float, s: Float, color: Int, alpha: Int = 255) {
        val a = alpha / 255f
        // Brillo exterior suave
        fill.color = Color.argb((60 * a).toInt(), Color.red(color), Color.green(color), Color.blue(color))
        tmpRect.set(x - s * 0.10f, y - s * 0.10f, x + s * 1.10f, y + s * 1.10f)
        c.drawRoundRect(tmpRect, s * 0.25f, s * 0.25f, fill)
        // Cuerpo
        fill.color = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
        tmpRect.set(x + s * 0.06f, y + s * 0.06f, x + s * 0.94f, y + s * 0.94f)
        c.drawRoundRect(tmpRect, s * 0.18f, s * 0.18f, fill)
        // Núcleo oscuro tipo pantalla
        val dark = blend(color, Color.BLACK, 0.62f)
        fill.color = Color.argb(alpha, Color.red(dark), Color.green(dark), Color.blue(dark))
        tmpRect.set(x + s * 0.26f, y + s * 0.26f, x + s * 0.74f, y + s * 0.74f)
        c.drawRoundRect(tmpRect, s * 0.10f, s * 0.10f, fill)
        // Reflejo
        fill.color = Color.argb((90 * a).toInt(), 255, 255, 255)
        tmpRect.set(x + s * 0.12f, y + s * 0.10f, x + s * 0.80f, y + s * 0.20f)
        c.drawRoundRect(tmpRect, s * 0.05f, s * 0.05f, fill)
    }

    private fun drawHud(c: Canvas) {
        val r = hudRect
        val hh = r.height()
        val leftW = (gameRects[Btn.PAUSE]?.left ?: r.right) - r.left - dp(10f)

        text(c, "SCORE", r.left, r.top + hh * 0.17f, hh * 0.15f, neonDim)
        text(
            c, engine.score.toString().padStart(6, '0'), r.left, r.top + hh * 0.56f,
            hh * 0.36f, neon, glow = true
        )
        val best = max(storage.best, engine.score)
        val x1 = r.left
        val x2 = r.left + leftW * 0.38f
        val x3 = r.left + leftW * 0.66f
        val ls = hh * 0.13f
        val vs = hh * 0.20f
        text(c, "BEST", x1, r.top + hh * 0.78f, ls, neonDim)
        text(c, best.toString(), x1, r.bottom, vs, neon)
        text(c, "LEVEL", x2, r.top + hh * 0.78f, ls, neonDim)
        text(c, engine.level.toString(), x2, r.bottom, vs, neon)
        text(c, "LINES", x3, r.top + hh * 0.78f, ls, neonDim)
        text(c, engine.lines.toString(), x3, r.bottom, vs, neon)

        // Vista previa de la siguiente pieza
        drawPanel(c, nextRect)
        text(c, "NEXT", nextRect.centerX(), nextRect.top + nextRect.height() * 0.22f,
            nextRect.height() * 0.15f, neonDim, Paint.Align.CENTER)
        val type = engine.nextType
        val off = type.offsets[0]
        var minR = 99; var maxR = -1; var minC = 99; var maxC = -1
        var i = 0
        while (i < 8) {
            minR = min(minR, off[i]); maxR = max(maxR, off[i])
            minC = min(minC, off[i + 1]); maxC = max(maxC, off[i + 1])
            i += 2
        }
        val ps = nextRect.height() * 0.19f
        val pw = (maxC - minC + 1) * ps
        val ph = (maxR - minR + 1) * ps
        val ox = nextRect.centerX() - pw / 2f
        val oy = nextRect.top + nextRect.height() * 0.30f +
            (nextRect.height() * 0.66f - ph) / 2f
        i = 0
        while (i < 8) {
            drawCell(c, ox + (off[i + 1] - minC) * ps, oy + (off[i] - minR) * ps, ps,
                pieceColors[type.colorIndex])
            i += 2
        }

        drawIconButton(c, Btn.PAUSE)
        drawIconButton(c, Btn.SOUND)
    }

    private fun drawPanel(c: Canvas, r: RectF) {
        fill.color = Color.argb(150, 0, 20, 6)
        c.drawRoundRect(r, dp(10f), dp(10f), fill)
        stroke.strokeWidth = dp(1.5f)
        stroke.color = Color.argb(160, 57, 255, 20)
        c.drawRoundRect(r, dp(10f), dp(10f), stroke)
    }

    private fun drawBoard(c: Canvas) {
        val l = boardLeft
        val t = boardTop
        val rr = l + boardW
        val bb = t + boardH

        fill.color = Color.argb(170, 0, 14, 4)
        c.drawRect(l, t, rr, bb, fill)

        stroke.strokeWidth = 1f
        stroke.color = Color.argb(30, 57, 255, 20)
        c.drawLines(gridLines, stroke)

        val clearing = engine.clearingRows
        val progress = engine.clearProgress.toFloat()

        for (row in GameEngine.HIDDEN_ROWS until GameEngine.ROWS) {
            val line = engine.grid[row]
            val isClearing = clearing.isNotEmpty() && clearing.contains(row)
            for (col in 0 until GameEngine.COLS) {
                val v = line[col]
                if (v == 0) continue
                val x = l + col * cell
                val y = t + (row - GameEngine.HIDDEN_ROWS) * cell
                if (isClearing) {
                    val flash = blend(pieceColors[v], Color.WHITE, 0.75f)
                    drawCell(c, x, y, cell, flash, (255 * (1f - progress * 0.85f)).toInt())
                } else {
                    drawCell(c, x, y, cell, pieceColors[v])
                }
            }
        }

        if (engine.pieceActive) {
            val type = engine.curType
            val off = type.offsets[engine.curRot]
            val color = pieceColors[type.colorIndex]

            // Fantasma
            val gy = engine.ghostY()
            if (gy != engine.curY) {
                stroke.strokeWidth = dp(1.5f)
                stroke.color = Color.argb(110, Color.red(color), Color.green(color), Color.blue(color))
                var i = 0
                while (i < 8) {
                    val rowG = gy + off[i]
                    if (rowG >= GameEngine.HIDDEN_ROWS) {
                        val x = l + (engine.curX + off[i + 1]) * cell
                        val y = t + (rowG - GameEngine.HIDDEN_ROWS) * cell
                        tmpRect.set(x + cell * 0.1f, y + cell * 0.1f, x + cell * 0.9f, y + cell * 0.9f)
                        c.drawRoundRect(tmpRect, cell * 0.15f, cell * 0.15f, stroke)
                    }
                    i += 2
                }
            }
            var i = 0
            while (i < 8) {
                val row = engine.curY + off[i]
                if (row >= GameEngine.HIDDEN_ROWS) {
                    drawCell(
                        c,
                        l + (engine.curX + off[i + 1]) * cell,
                        t + (row - GameEngine.HIDDEN_ROWS) * cell,
                        cell, color
                    )
                }
                i += 2
            }
        }

        // Marco con brillo
        stroke.strokeWidth = dp(5f)
        stroke.color = Color.argb(40, 57, 255, 20)
        c.drawRect(l - dp(1f), t - dp(1f), rr + dp(1f), bb + dp(1f), stroke)
        stroke.strokeWidth = dp(1.8f)
        stroke.color = neon
        c.drawRect(l - dp(1f), t - dp(1f), rr + dp(1f), bb + dp(1f), stroke)
    }

    private fun drawControls(c: Canvas) {
        for (b in arrayOf(Btn.LEFT, Btn.RIGHT, Btn.ROTATE, Btn.DOWN)) {
            val r = gameRects[b] ?: continue
            val down = pressed.contains(b)
            fill.color = if (down) Color.argb(200, 20, 120, 30) else Color.argb(150, 0, 28, 8)
            c.drawRoundRect(r, dp(18f), dp(18f), fill)
            stroke.strokeWidth = dp(2f)
            stroke.color = if (down) neon else Color.argb(190, 57, 255, 20)
            c.drawRoundRect(r, dp(18f), dp(18f), stroke)
            drawIcon(c, b, r, if (down) Color.WHITE else neon)
        }
    }

    private fun drawIconButton(c: Canvas, b: Btn) {
        val r = gameRects[b] ?: return
        val down = pressed.contains(b)
        fill.color = if (down) Color.argb(200, 20, 120, 30) else Color.argb(150, 0, 28, 8)
        c.drawRoundRect(r, dp(10f), dp(10f), fill)
        stroke.strokeWidth = dp(1.5f)
        stroke.color = Color.argb(190, 57, 255, 20)
        c.drawRoundRect(r, dp(10f), dp(10f), stroke)
        drawIcon(c, b, r, neon)
    }

    private fun drawIcon(c: Canvas, b: Btn, r: RectF, color: Int) {
        val cx = r.centerX()
        val cy = r.centerY()
        val u = min(r.width(), r.height())
        fill.color = color
        stroke.color = color
        when (b) {
            Btn.LEFT, Btn.RIGHT -> {
                val s = u * 0.22f
                val dir = if (b == Btn.LEFT) -1f else 1f
                path.reset()
                path.moveTo(cx + dir * s, cy)
                path.lineTo(cx - dir * s * 0.8f, cy - s * 1.2f)
                path.lineTo(cx - dir * s * 0.8f, cy + s * 1.2f)
                path.close()
                c.drawPath(path, fill)
            }
            Btn.ROTATE -> {
                val rad = min(r.height() * 0.24f, r.width() * 0.14f)
                val ix = cx - r.width() * 0.16f
                tmpRect.set(ix - rad, cy - rad, ix + rad, cy + rad)
                stroke.strokeWidth = dp(3.5f)
                c.drawArc(tmpRect, 40f, 280f, false, stroke)
                val ang = (40f + 280f) * PI.toFloat() / 180f
                val ex = ix + rad * cos(ang)
                val ey = cy + rad * sin(ang)
                val tx = -sin(ang)
                val ty = cos(ang)
                val hs = rad * 0.7f
                path.reset()
                path.moveTo(ex + tx * hs, ey + ty * hs)
                path.lineTo(ex + cos(ang) * hs * 0.8f, ey + sin(ang) * hs * 0.8f)
                path.lineTo(ex - cos(ang) * hs * 0.8f, ey - sin(ang) * hs * 0.8f)
                path.close()
                c.drawPath(path, fill)
                text(c, "ROTAR", cx + r.width() * 0.18f, cy + r.height() * 0.10f,
                    min(r.height() * 0.22f, r.width() * 0.17f), color, Paint.Align.CENTER)
            }
            Btn.DOWN -> {
                val s = min(r.height() * 0.18f, r.width() * 0.08f)
                val ix = cx - r.width() * 0.2f
                stroke.strokeWidth = dp(3.5f)
                path.reset()
                path.moveTo(ix - s, cy - s * 0.9f)
                path.lineTo(ix, cy)
                path.lineTo(ix + s, cy - s * 0.9f)
                c.drawPath(path, stroke)
                path.reset()
                path.moveTo(ix - s, cy + s * 0.2f)
                path.lineTo(ix, cy + s * 1.1f)
                path.lineTo(ix + s, cy + s * 0.2f)
                c.drawPath(path, stroke)
                text(c, "CAER", cx + r.width() * 0.16f, cy + r.height() * 0.12f,
                    min(r.height() * 0.28f, r.width() * 0.17f), color, Paint.Align.CENTER)
            }
            Btn.PAUSE -> {
                val bw = u * 0.12f
                val bh = u * 0.30f
                c.drawRoundRect(cx - bw * 1.6f, cy - bh, cx - bw * 0.4f, cy + bh, 3f, 3f, fill)
                c.drawRoundRect(cx + bw * 0.4f, cy - bh, cx + bw * 1.6f, cy + bh, 3f, 3f, fill)
            }
            Btn.SOUND -> {
                val s = u * 0.18f
                path.reset()
                path.moveTo(cx - s * 1.6f, cy - s * 0.6f)
                path.lineTo(cx - s * 0.7f, cy - s * 0.6f)
                path.lineTo(cx + s * 0.2f, cy - s * 1.4f)
                path.lineTo(cx + s * 0.2f, cy + s * 1.4f)
                path.lineTo(cx - s * 0.7f, cy + s * 0.6f)
                path.lineTo(cx - s * 1.6f, cy + s * 0.6f)
                path.close()
                c.drawPath(path, fill)
                stroke.strokeWidth = dp(2f)
                if (storage.muted) {
                    c.drawLine(cx + s * 0.7f, cy - s * 0.8f, cx + s * 1.7f, cy + s * 0.8f, stroke)
                    c.drawLine(cx + s * 1.7f, cy - s * 0.8f, cx + s * 0.7f, cy + s * 0.8f, stroke)
                } else {
                    tmpRect.set(cx - s * 0.2f, cy - s * 0.9f, cx + s * 1.2f, cy + s * 0.9f)
                    c.drawArc(tmpRect, -50f, 100f, false, stroke)
                    tmpRect.set(cx - s * 0.2f, cy - s * 1.5f, cx + s * 1.9f, cy + s * 1.5f)
                    c.drawArc(tmpRect, -50f, 100f, false, stroke)
                }
            }
            else -> {}
        }
    }

    // ---------------------------------------------------------- pantallas

    private fun drawOverlayButtons(c: Canvas) {
        val list = overlayButtons()
        for (i in list.indices) {
            val (b, label) = list[i]
            val r = overlayRects[i]
            val down = pressed.contains(b)
            fill.color = if (down) Color.argb(230, 20, 140, 35) else Color.argb(200, 0, 34, 10)
            c.drawRoundRect(r, dp(16f), dp(16f), fill)
            stroke.strokeWidth = dp(2f)
            stroke.color = neon
            c.drawRoundRect(r, dp(16f), dp(16f), stroke)
            text(c, label, r.centerX(), r.centerY() + dp(7f), dp(20f),
                if (down) Color.WHITE else neon, Paint.Align.CENTER, glow = true)
        }
    }

    private fun drawHome(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val big = min(w * 0.21f, dp(88f))
        text(c, "NEON", w / 2f, h * 0.22f, big, neon, Paint.Align.CENTER, glow = true)
        text(c, "TETRIS", w / 2f, h * 0.22f + big * 1.0f, big * 0.82f,
            Color.rgb(182, 255, 59), Paint.Align.CENTER, glow = true)
        text(c, "MATRIX EDITION", w / 2f, h * 0.22f + big * 1.55f, dp(14f), neonDim, Paint.Align.CENTER)
        text(c, "BEST  " + storage.best.toString().padStart(6, '0'), w / 2f, h * 0.43f,
            dp(20f), neon, Paint.Align.CENTER, glow = true)
        drawOverlayButtons(c)
        text(c, "TOCA EL TABLERO PARA ROTAR · DESLIZA PARA MOVER",
            w / 2f, h - insetB - dp(26f), dp(10f), neonDim, Paint.Align.CENTER)
    }

    private fun dim(c: Canvas) {
        fill.color = Color.argb(205, 0, 0, 0)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
    }

    private fun drawPause(c: Canvas) {
        dim(c)
        val w = width.toFloat()
        val h = height.toFloat()
        text(c, "PAUSA", w / 2f, h * 0.30f, min(w * 0.17f, dp(70f)), neon, Paint.Align.CENTER, glow = true)
        text(c, "SCORE " + engine.score, w / 2f, h * 0.38f, dp(18f), neonDim, Paint.Align.CENTER)
        drawOverlayButtons(c)
    }

    private fun drawGameOver(c: Canvas) {
        dim(c)
        val w = width.toFloat()
        val h = height.toFloat()
        text(c, "GAME OVER", w / 2f, h * 0.27f, min(w * 0.14f, dp(56f)),
            Color.rgb(255, 80, 80), Paint.Align.CENTER, glow = true)
        text(c, "SCORE  " + engine.score, w / 2f, h * 0.34f, dp(22f), neon, Paint.Align.CENTER, glow = true)
        text(c, "BEST   " + max(storage.best, engine.score), w / 2f, h * 0.39f, dp(18f),
            neonDim, Paint.Align.CENTER)
        if (newRecord) {
            text(c, "NUEVO RECORD", w / 2f, h * 0.44f, dp(18f),
                Color.rgb(182, 255, 59), Paint.Align.CENTER, glow = true)
        }
        drawOverlayButtons(c)
    }

    private companion object {
        const val DAS_MS = 170L
        const val REPEAT_MS = 55L
        const val HARD_TAP_MS = 150L
    }
}
