package cl.neontetris.game

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import cl.neontetris.game.engine.GameEngine

class MainActivity : ComponentActivity() {

    private lateinit var storage: Storage
    private lateinit var sound: SoundManager
    private lateinit var engine: GameEngine
    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Pantalla completa "de borde a borde"; los controles respetan las zonas del sistema.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        storage = Storage(this)
        sound = SoundManager(this)
        engine = GameEngine()
        gameView = GameView(this, engine, storage, sound)
        setContentView(gameView)

        WindowInsetsControllerCompat(window, gameView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        ViewCompat.setOnApplyWindowInsetsListener(gameView) { _, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.mandatorySystemGestures()
            )
            gameView.setSafeInsets(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }

        // Si Android cerró la app mientras había una partida, se recupera en pausa.
        val saved = storage.savedGame
        if (saved != null && engine.restore(saved)) {
            gameView.onRestoredGame()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!gameView.handleBack()) finish()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        gameView.onHostResume()
    }

    override fun onPause() {
        // La partida se pone en pausa y se guarda al salir de la app.
        gameView.onHostPause()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        sound.release()
    }
}
