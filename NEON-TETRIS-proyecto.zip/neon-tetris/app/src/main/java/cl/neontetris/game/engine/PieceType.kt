package cl.neontetris.game.engine

/**
 * Las siete piezas tradicionales. Cada pieza se define por su matriz base;
 * las cuatro rotaciones se precalculan como desplazamientos planos
 * [fila0, col0, fila1, col1, ...] de sus 4 celdas.
 */
enum class PieceType(val colorIndex: Int, shape: List<String>) {
    I(1, listOf("....", "XXXX", "....", "....")),
    O(2, listOf("XX", "XX")),
    T(3, listOf(".X.", "XXX", "...")),
    S(4, listOf(".XX", "XX.", "...")),
    Z(5, listOf("XX.", ".XX", "...")),
    J(6, listOf("X..", "XXX", "...")),
    L(7, listOf("..X", "XXX", "..."));

    /** Lado de la matriz cuadrada de la pieza. */
    val size: Int = shape.size

    /** offsets[rotación] = [fila, col, fila, col, ...] (4 celdas). */
    val offsets: Array<IntArray> = buildOffsets(shape)
}

private fun buildOffsets(shape: List<String>): Array<IntArray> {
    val n = shape.size
    var m = Array(n) { r -> BooleanArray(n) { c -> shape[r][c] == 'X' } }
    val result = ArrayList<IntArray>()
    for (rot in 0 until 4) {
        val flat = IntArray(8)
        var k = 0
        for (r in 0 until n) {
            for (c in 0 until n) {
                if (m[r][c]) {
                    flat[k] = r
                    flat[k + 1] = c
                    k += 2
                }
            }
        }
        result.add(flat)
        // Rotación horaria de la matriz.
        val rotated = Array(n) { BooleanArray(n) }
        for (r in 0 until n) {
            for (c in 0 until n) {
                rotated[c][n - 1 - r] = m[r][c]
            }
        }
        m = rotated
    }
    return result.toTypedArray()
}
