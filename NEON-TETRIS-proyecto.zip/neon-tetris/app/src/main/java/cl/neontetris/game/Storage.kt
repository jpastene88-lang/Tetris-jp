package cl.neontetris.game

import android.content.Context

/** Récord, opción de sonido y partida en curso, guardados en el teléfono. */
class Storage(context: Context) {

    private val prefs = context.getSharedPreferences("neon_tetris", Context.MODE_PRIVATE)

    var best: Int
        get() = prefs.getInt("best", 0)
        set(value) {
            prefs.edit().putInt("best", value).apply()
        }

    var muted: Boolean
        get() = prefs.getBoolean("muted", false)
        set(value) {
            prefs.edit().putBoolean("muted", value).apply()
        }

    /** Partida serializada, o null si no hay ninguna en curso. */
    var savedGame: String?
        get() = prefs.getString("saved_game", null)
        set(value) {
            if (value == null) {
                prefs.edit().remove("saved_game").apply()
            } else {
                prefs.edit().putString("saved_game", value).apply()
            }
        }
}
