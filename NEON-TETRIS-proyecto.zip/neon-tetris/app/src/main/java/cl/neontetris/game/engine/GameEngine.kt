package cl.neontetris.game.engine

import java.util.Collections
import java.util.Random

/**
 * Motor del juego. No depende de Android: solo reglas, estado y puntuación.
 * Todo el tiempo se expresa en milisegundos (Double).
 *
 * El tablero tiene COLS x ROWS celdas; las primeras HIDDEN_ROWS filas son una
 * zona oculta donde aparecen las piezas. Las 20 filas inferiores son visibles.
 */
class GameEngine(private val random: Random = Random()) {

    enum class State { READY, RUNNING, PAUSED, GAME_OVER }

    interface Listener {
        fun onMove() {}
        fun onRotate() {}
        fun onHardDrop() {}
        fun onLock() {}
        fun onLinesCleared(count: Int) {}
        fun onLevelUp(level: Int) {}
        fun onGameOver() {}
    }

    companion object {
        const val COLS = 10
        const val VISIBLE_ROWS = 20
        const val HIDDEN_ROWS = 2
        const val ROWS = VISIBLE_ROWS + HIDDEN_ROWS

        const val CLEAR_ANIM_MS = 260.0
        const val LOCK_DELAY_MS = 450.0
        const val SOFT_LOCK_DELAY_MS = 90.0
        const val MAX_LOCK_RESETS = 15
        const val SOFT_DROP_INTERVAL_MS = 45.0

        private val LINE_POINTS = intArrayOf(0, 100, 300, 500, 800)

        // Desplazamientos (dx, dy) que se prueban al rotar junto a paredes/pilas.
        private val KICKS = arrayOf(
            intArrayOf(0, 0), intArrayOf(-1, 0), intArrayOf(1, 0),
            intArrayOf(-2, 0), intArrayOf(2, 0), intArrayOf(0, -1)
        )

        /** Intervalo de caída automática (ms por fila) según el nivel. */
        fun intervalForLevel(level: Int): Double =
            Math.max(60.0, 900.0 * Math.pow(0.8, (level - 1).toDouble()))
    }

    val grid = Array(ROWS) { IntArray(COLS) }

    var state = State.READY
        private set
    var score = 0
        private set
    var lines = 0
        private set
    var level = 1
        private set

    var curType = PieceType.T
        private set
    var curRot = 0
        private set
    var curX = 0
        private set
    var curY = 0
        private set
    var nextType = PieceType.I
        private set
    var pieceActive = false
        private set

    /** Filas completas en animación de borrado (vacío si no hay). */
    var clearingRows = IntArray(0)
        private set

    /** Mientras sea true la pieza cae rápido (botón mantenido). */
    var softDrop = false

    var listener: Listener? = null

    private var clearTimer = 0.0
    private var gravityAcc = 0.0
    private var lockMs = 0.0
    private var lockResets = 0
    private val bag = ArrayList<PieceType>()

    /** 0..1 durante la animación de borrado. */
    val clearProgress: Double
        get() = if (clearingRows.isEmpty()) 0.0 else 1.0 - clearTimer / CLEAR_ANIM_MS

    // ------------------------------------------------------------------ ciclo

    fun start() {
        for (row in grid) java.util.Arrays.fill(row, 0)
        score = 0
        lines = 0
        level = 1
        bag.clear()
        clearingRows = IntArray(0)
        clearTimer = 0.0
        softDrop = false
        state = State.RUNNING
        nextType = drawPiece()
        spawnNext()
    }

    fun pause() {
        softDrop = false
        if (state == State.RUNNING) {
            if (clearingRows.isNotEmpty()) finishClear()
            if (state == State.RUNNING) state = State.PAUSED
        }
    }

    fun resume() {
        if (state == State.PAUSED) state = State.RUNNING
    }

    // ------------------------------------------------------------- movimiento

    fun moveLeft(): Boolean = shift(-1)

    fun moveRight(): Boolean = shift(1)

    private fun shift(dx: Int): Boolean {
        if (!canControl()) return false
        if (collides(curType, curRot, curX + dx, curY)) return false
        curX += dx
        onAdjusted()
        listener?.onMove()
        return true
    }

    fun rotate(): Boolean {
        if (!canControl()) return false
        val newRot = (curRot + 1) % 4
        for (k in KICKS) {
            val nx = curX + k[0]
            val ny = curY + k[1]
            if (!collides(curType, newRot, nx, ny)) {
                curRot = newRot
                curX = nx
                curY = ny
                onAdjusted()
                listener?.onRotate()
                return true
            }
        }
        return false
    }

    /** Caída instantánea. Devuelve las filas descendidas. */
    fun hardDrop(): Int {
        if (!canControl()) return 0
        var dist = 0
        while (!collides(curType, curRot, curX, curY + 1)) {
            curY++
            dist++
        }
        score += 2 * dist
        listener?.onHardDrop()
        lock()
        return dist
    }

    /** Fila donde quedaría la pieza actual si cayera ahora (para el "fantasma"). */
    fun ghostY(): Int {
        var y = curY
        while (!collides(curType, curRot, curX, y + 1)) y++
        return y
    }

    // ------------------------------------------------------------- simulación

    fun update(dtMs: Double) {
        if (state != State.RUNNING) return

        if (clearingRows.isNotEmpty()) {
            clearTimer -= dtMs
            if (clearTimer <= 0.0) finishClear()
            return
        }
        if (!pieceActive) return

        val grounded = collides(curType, curRot, curX, curY + 1)
        if (grounded) {
            gravityAcc = 0.0
            lockMs += dtMs
            val limit = if (softDrop) SOFT_LOCK_DELAY_MS else LOCK_DELAY_MS
            if (lockMs >= limit) lock()
        } else {
            lockMs = 0.0
            val interval = if (softDrop) {
                Math.min(intervalForLevel(level), SOFT_DROP_INTERVAL_MS)
            } else {
                intervalForLevel(level)
            }
            gravityAcc += dtMs
            while (gravityAcc >= interval) {
                gravityAcc -= interval
                if (collides(curType, curRot, curX, curY + 1)) break
                curY++
                if (softDrop) score += 1
            }
        }
    }

    // --------------------------------------------------------------- internos

    private fun canControl(): Boolean =
        state == State.RUNNING && pieceActive && clearingRows.isEmpty()

    private fun onAdjusted() {
        if (lockMs > 0.0 && lockResets < MAX_LOCK_RESETS) {
            lockMs = 0.0
            lockResets++
        }
    }

    private fun collides(type: PieceType, rot: Int, x: Int, y: Int): Boolean {
        val off = type.offsets[rot]
        var i = 0
        while (i < 8) {
            val r = y + off[i]
            val c = x + off[i + 1]
            if (c < 0 || c >= COLS || r >= ROWS) return true
            if (r >= 0 && grid[r][c] != 0) return true
            i += 2
        }
        return false
    }

    private fun lock() {
        val off = curType.offsets[curRot]
        var allHidden = true
        var i = 0
        while (i < 8) {
            val r = curY + off[i]
            val c = curX + off[i + 1]
            if (r in 0 until ROWS && c in 0 until COLS) grid[r][c] = curType.colorIndex
            if (r >= HIDDEN_ROWS) allHidden = false
            i += 2
        }
        pieceActive = false
        listener?.onLock()

        if (allHidden) {
            gameOver()
            return
        }

        val full = ArrayList<Int>()
        for (r in 0 until ROWS) {
            if (grid[r].all { it != 0 }) full.add(r)
        }
        if (full.isNotEmpty()) {
            clearingRows = full.toIntArray()
            clearTimer = CLEAR_ANIM_MS
        } else {
            spawnNext()
        }
    }

    private fun finishClear() {
        val count = clearingRows.size
        val cleared = clearingRows.toSet()
        val keep = ArrayList<IntArray>()
        for (r in 0 until ROWS) {
            if (r !in cleared) keep.add(grid[r])
        }
        for (r in 0 until ROWS) {
            grid[r] = if (r < count) IntArray(COLS) else keep[r - count]
        }

        score += LINE_POINTS[Math.min(count, 4)] * level
        lines += count
        clearingRows = IntArray(0)
        clearTimer = 0.0
        listener?.onLinesCleared(count)

        val newLevel = lines / 10 + 1
        if (newLevel > level) {
            level = newLevel
            listener?.onLevelUp(level)
        }
        spawnNext()
    }

    private fun spawnNext() {
        curType = nextType
        nextType = drawPiece()
        curRot = 0
        curX = (COLS - curType.size) / 2
        curY = HIDDEN_ROWS - 1
        gravityAcc = 0.0
        lockMs = 0.0
        lockResets = 0
        if (collides(curType, curRot, curX, curY)) {
            gameOver()
        } else {
            pieceActive = true
        }
    }

    private fun gameOver() {
        pieceActive = false
        state = State.GAME_OVER
        softDrop = false
        listener?.onGameOver()
    }

    /** Bolsa de 7: cada pieza aparece una vez por ciclo, en orden aleatorio. */
    private fun drawPiece(): PieceType {
        if (bag.isEmpty()) {
            bag.addAll(PieceType.values())
            Collections.shuffle(bag, random)
        }
        return bag.removeAt(bag.size - 1)
    }

    // ---------------------------------------------------- guardado / carga

    /** Estado serializado (para no perder la partida si Android cierra la app). */
    fun serialize(): String {
        val parts = listOf(
            "1",
            score.toString(),
            lines.toString(),
            level.toString(),
            curType.ordinal.toString(),
            curRot.toString(),
            curX.toString(),
            curY.toString(),
            nextType.ordinal.toString(),
            if (pieceActive) "1" else "0",
            state.ordinal.toString(),
            bag.joinToString(",") { it.ordinal.toString() },
            grid.joinToString("") { row -> row.joinToString("") { it.toString() } }
        )
        return parts.joinToString(";")
    }

    /**
     * Restaura una partida guardada. Devuelve false (sin tocar el estado
     * actual) si los datos son inválidos o la partida no estaba en curso.
     * Una partida en curso se restaura en pausa.
     */
    fun restore(data: String): Boolean {
        try {
            val p = data.split(";")
            if (p.size != 13 || p[0] != "1") return false
            val types = PieceType.values()

            val nScore = p[1].toInt()
            val nLines = p[2].toInt()
            val nLevel = p[3].toInt()
            val nCur = types[p[4].toInt()]
            val nRot = p[5].toInt()
            val nX = p[6].toInt()
            val nY = p[7].toInt()
            val nNext = types[p[8].toInt()]
            val nActive = p[9] == "1"
            val savedState = State.values()[p[10].toInt()]
            val nBag = ArrayList<PieceType>()
            if (p[11].isNotEmpty()) {
                for (s in p[11].split(",")) nBag.add(types[s.toInt()])
            }
            val cells = p[12]

            if (savedState != State.RUNNING && savedState != State.PAUSED) return false
            if (nScore < 0 || nLines < 0 || nLevel < 1) return false
            if (nRot !in 0..3) return false
            if (cells.length != ROWS * COLS) return false

            val newGrid = Array(ROWS) { IntArray(COLS) }
            for (r in 0 until ROWS) {
                for (c in 0 until COLS) {
                    val v = cells[r * COLS + c] - '0'
                    if (v < 0 || v > 7) return false
                    newGrid[r][c] = v
                }
            }

            // Se valida con el tablero nuevo antes de aplicar nada.
            if (nActive && collidesOn(newGrid, nCur, nRot, nX, nY)) return false

            for (r in 0 until ROWS) System.arraycopy(newGrid[r], 0, grid[r], 0, COLS)
            score = nScore
            lines = nLines
            level = nLevel
            curType = nCur
            curRot = nRot
            curX = nX
            curY = nY
            nextType = nNext
            pieceActive = nActive
            bag.clear()
            bag.addAll(nBag)
            clearingRows = IntArray(0)
            clearTimer = 0.0
            gravityAcc = 0.0
            lockMs = 0.0
            lockResets = 0
            softDrop = false
            state = State.PAUSED
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun collidesOn(g: Array<IntArray>, type: PieceType, rot: Int, x: Int, y: Int): Boolean {
        val off = type.offsets[rot]
        var i = 0
        while (i < 8) {
            val r = y + off[i]
            val c = x + off[i + 1]
            if (c < 0 || c >= COLS || r >= ROWS) return true
            if (r >= 0 && g[r][c] != 0) return true
            i += 2
        }
        return false
    }

    // ------------------------------------------------------- ayudas de prueba

    internal fun debugSetPiece(type: PieceType, rot: Int, x: Int, y: Int) {
        curType = type
        curRot = rot
        curX = x
        curY = y
        pieceActive = true
        lockMs = 0.0
        gravityAcc = 0.0
    }

    internal fun debugDraw(): PieceType = drawPiece()
}
