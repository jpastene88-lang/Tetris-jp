package cl.neontetris.game

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Efectos retro generados por código (ondas cuadradas): no hay archivos de
 * audio en el proyecto. Se escriben una vez en la caché como .wav y se cargan
 * en un SoundPool.
 */
class SoundManager(private val context: Context) {

    enum class Sfx(val notes: List<Pair<Int, Int>>) { // (Hz, ms)
        MOVE(listOf(300 to 22)),
        ROTATE(listOf(520 to 28, 780 to 28)),
        LOCK(listOf(170 to 55)),
        DROP(listOf(260 to 30, 120 to 80)),
        LINE(listOf(523 to 70, 659 to 70, 784 to 70, 1047 to 130)),
        LEVEL(listOf(659 to 80, 784 to 80, 988 to 80, 1319 to 170)),
        OVER(listOf(392 to 160, 330 to 160, 262 to 160, 196 to 380))
    }

    @Volatile
    var muted = false

    private val sampleRate = 22050
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()
    private val ids = HashMap<Sfx, Int>()
    private val loaded = HashSet<Int>()

    init {
        pool.setOnLoadCompleteListener { _, id, status ->
            if (status == 0) loaded.add(id)
        }
        for (s in Sfx.values()) {
            try {
                val file = File(context.cacheDir, "sfx_v1_" + s.name.lowercase() + ".wav")
                if (!file.exists()) file.writeBytes(buildWav(s.notes))
                ids[s] = pool.load(file.absolutePath, 1)
            } catch (e: Exception) {
                // Sin sonido es mejor que cerrar el juego.
            }
        }
    }

    fun play(sfx: Sfx) {
        if (muted) return
        val id = ids[sfx] ?: return
        if (id in loaded) pool.play(id, 0.6f, 0.6f, 1, 0, 1f)
    }

    fun release() {
        pool.release()
    }

    private fun buildWav(notes: List<Pair<Int, Int>>): ByteArray {
        val samples = ArrayList<Short>()
        for ((freq, ms) in notes) {
            val count = sampleRate * ms / 1000
            val period = sampleRate.toDouble() / freq
            for (i in 0 until count) {
                val phase = (i % period) / period
                val square = if (phase < 0.5) 1.0 else -1.0
                val envelope = 1.0 - (i.toDouble() / count) * 0.85
                samples.add((square * envelope * 9000).toInt().toShort())
            }
        }
        val dataSize = samples.size * 2
        val buf = ByteBuffer.allocate(44 + dataSize).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray(Charsets.US_ASCII))
        buf.putInt(36 + dataSize)
        buf.put("WAVE".toByteArray(Charsets.US_ASCII))
        buf.put("fmt ".toByteArray(Charsets.US_ASCII))
        buf.putInt(16)
        buf.putShort(1) // PCM
        buf.putShort(1) // mono
        buf.putInt(sampleRate)
        buf.putInt(sampleRate * 2)
        buf.putShort(2)
        buf.putShort(16)
        buf.put("data".toByteArray(Charsets.US_ASCII))
        buf.putInt(dataSize)
        for (s in samples) buf.putShort(s)
        return buf.array()
    }
}
